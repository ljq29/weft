"""Isolated workflow worker package."""

__version__ = "0.5.3"

__all__ = ["__version__"]
