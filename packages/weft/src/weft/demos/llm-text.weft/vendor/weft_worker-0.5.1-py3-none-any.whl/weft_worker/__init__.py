"""Isolated workflow worker package."""

__version__ = "0.5.1"

__all__ = ["__version__"]
